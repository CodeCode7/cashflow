sap.ui.define([
	"./utilities"
], function() {
	"use strict";

	// class providing static utility methods to retrieve entity default values.

	return {
		getDefaultValuesForPage2: function() {
			return {
				"ID": "id-" + Date.now().toString(),
				"MessageID": "",
				"MessageName1": "",
				"___FK_85d8ca7c5e5095aa16b40281_00007": "",
				"ContractorUserName": "",
				"ContractorUserGroup": "",
				"AllContractors": true,
				"Active": true,
				"ScheduledStart": null,
				"ScheduledEnd": null,
				"Reminder": true,
				"MessageDescription": "",
				"Createdon": null,
				"Creayedat": null,
				"Createdby": ""
			};
		}
	};
});
