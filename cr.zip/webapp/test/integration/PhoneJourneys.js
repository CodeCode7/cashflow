jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"cr/cr/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"cr/cr/test/integration/pages/App",
	"cr/cr/test/integration/pages/Browser",
	"cr/cr/test/integration/pages/Master",
	"cr/cr/test/integration/pages/Detail",
	"cr/cr/test/integration/pages/NotFound"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "cr.cr.view."
	});

	sap.ui.require([
		"cr/cr/test/integration/NavigationJourneyPhone",
		"cr/cr/test/integration/NotFoundJourneyPhone",
		"cr/cr/test/integration/BusyJourneyPhone"
	], function () {
		QUnit.start();
	});
});