jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

// We cannot provide stable mock data out of the template.
// If you introduce mock data, by adding .json files in your webapp/localService/mockdata folder you have to provide the following minimum data:
// * At least 3 EMPSet in the list

sap.ui.require([
	"sap/ui/test/Opa5",
	"cr/cr/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"cr/cr/test/integration/pages/App",
	"cr/cr/test/integration/pages/Browser",
	"cr/cr/test/integration/pages/Master",
	"cr/cr/test/integration/pages/Detail",
	"cr/cr/test/integration/pages/Create",
	"cr/cr/test/integration/pages/NotFound"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "cr.cr.view."
	});

	sap.ui.require([
		"cr/cr/test/integration/MasterJourney",
		"cr/cr/test/integration/NavigationJourney",
		"cr/cr/test/integration/NotFoundJourney",
		"cr/cr/test/integration/BusyJourney",
		"cr/cr/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});