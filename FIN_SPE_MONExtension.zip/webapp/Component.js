jQuery.sap.declare("fin.co.myspend.monitor.FIN_SPE_MONExtension.Component");

// use the load function for getting the optimized preload file if present
sap.ui.component.load({
	name: "fin.co.myspend.monitor",
	// Use the below URL to run the extended application when SAP-delivered application is deployed on SAPUI5 ABAP Repository
	url: "/sap/bc/ui5_ui5/sap/FIN_SPE_MON"
		// we use a URL relative to our own component
		// extension application is deployed with customer namespace
});

this.fin.co.myspend.monitor.Component.extend("fin.co.myspend.monitor.FIN_SPE_MONExtension.Component", {
	metadata: {
		version: "1.0.0",
		config: {},

		customizing: {}
	}
});